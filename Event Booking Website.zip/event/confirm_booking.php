<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require ('include/links.php') ?>
    <title>CONFIRM BOOKING</title>
</head>

<body class="bg-light">

    <?php require ('include/header.php'); ?>

    <?php
    if (!isset($settings_r['shutdown']) == true) {
        redirect('events.php');
    } else if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
        redirect('events.php');
    }

    $user_res = select("SELECT * FROM `user_cred` WHERE `id`=? LIMIT 1", [$_SESSION['uId']], "i");
    $user_data = mysqli_fetch_assoc($user_res);

    ?>

    <div class="container">
        <div class="row">
            <div class="col-12 my-5 mb-4 px-4">
                <h2 class="fw-bold">CONFIRM BOOKING</h2>
                <div style="font-size: 14px;">
                    <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                    <span class="text-secondary"> > </span>
                    <a href="events.php" class="text-secondary text-decoration-none">EVENTS</a>
                    <span class="text-secondary"> > </span>
                    <a href="#" class="text-secondary text-decoration-none">CONFIRM</a>
                </div>
            </div>


            <div class="col-lg-6 col-md-12 px-4 mx-auto">
                <div class="card mb-4 border-0 shadow-sm rounded-3">
                    <div class="card-body">
                        <form action="#" id="booking-form">
                            <h3 class="mb-5 text-center">BOOKING DETAILS</h3>
                            <di class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Name</label>
                                    <input name="name" type="text"
                                        value="<?php echo $user_data['name'] . ' ' . $user_data['lastname']; ?>"
                                        class="form-control shadow-none" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone number</label>
                                    <input name="phonenum" type="number" value="<?php echo $user_data['phonenum']; ?>"
                                        class="form-control shadow-none" required>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Address</label>
                                    <input name="address"
                                        value="<?php echo $user_data['address'] . ', ' . $user_data['pincode']; ?>"
                                        class="form-control shadow-none" rows="1" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date</label>
                                    <input name="date" type="date" class="form-control shadow-none" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Time Slot</label>
                                    <select name="time" class="form-select shadow-none">
                                        <option value="8:00am-3:00pm">8:00am-3:00pm</option>
                                        <option value="4:00pm-10:00am">4:00pm-10:00am</option>
                                        <option value="8:00am-10:00pm">8:00am-10:00pm</option>
                                    </select>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label class="form-label" style="font-weight:500;">Event</label>
                                    <select id="eventSelect" name="event" class="form-select shadow-none">
                                        <option value="Wedding Ceremony">Wedding Ceremony</option>
                                        <option value="Engagement Ceremony">Engagement Ceremony</option>
                                        <option value="Reception Ceremony">Reception Ceremony</option>
                                        <option value="Co-operate Event">Co-operate Event</option>
                                        <option value="Birthday Party">Birthday Party</option>
                                        <option value="Anniversary Party">Anniversary Party</option>
                                        <option value="Baby Shower">Baby Shower</option>
                                        <option value="Naming Ceremony">Naming Ceremony</option>
                                    </select>
                                </div>

                                <div class="col-md-12 mb-3 text-center">
                                    <span id="msg" style="font-weight:bold;"></span>
                                </div>                               

                                <div class="col-12">
                                    <button type="submit" name="submit_now" 
                                        class="btn w-100 text-white custom-bg shadow-none mb-1"> Submit
                                    </button>                                   
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php require ('include/footer.php'); ?>
    <script>

        // Disable pay button initially
        let booking_form = document.getElementById('booking-form');
        booking_form.addEventListener('submit', (e) => {
            e.preventDefault();

            let today = new Date();
            today.setHours(0, 0, 0, 0); // Set hours to 0 for accurate comparison

            // Get the selected date from the form
            let selectedDate = new Date(booking_form.elements['date'].value);

            // Check if the selected date is less than today's date
            if (selectedDate <= today) {
                alert('error', "Invalid Date");
                return; // Prevent form submission if the date is invalid
            }

            let data = new FormData();

            data.append('name', booking_form.elements['name'].value);
            data.append('phonenum', booking_form.elements['phonenum'].value);
            data.append('address', booking_form.elements['address'].value);
            data.append('date', booking_form.elements['date'].value);


            // Get the selected time slot value and store it in the FormData
            let selectedTimeSlotValue = booking_form.elements['time'].value;
            data.append('timeslot', selectedTimeSlotValue);

            // Get the selected event value and store it in the FormData
            let selectedEventValue = booking_form.elements['event'].value;
            data.append('event', selectedEventValue);
            data.append('booking', '');



            let xhr = new XMLHttpRequest();
            xhr.open('POST', 'ajax/confirm_booking.php', true);

            xhr.onload = function () {
                if (this.responseText == 'booking_already') {
                    alert('error', "Booking is not available for the selected timeslot.");
                } else if (this.responseText == 'ins_failed') {
                    alert('error', "Failed to confirm booking. Please try again later.");
                } else {
                    alert('success', "Booking Successful!");
                }
            };

            xhr.send(data); // Moved outside the onload function
        });

        let submit_button = booking_form.querySelector('[name="submit_now"]');
        submit_button.disabled = true;

        document.getElementById("eventSelect").addEventListener("change", function () {
            let selectedEvent = this.value;


            // Update price based on selected event
            switch (selectedEvent) {
                case "Wedding Ceremony": // Wedding Ceremony
                    msg = "Thank-you for choosing our venue for Wedding Ceremony!";
                    break;
                case "Engagement Ceremony": // Engagement Ceremony
                    msg = "Thank-you for choosing our venue for Engagement Ceremony!";
                    break;
                case "Reception Ceremony": // Reception Ceremony
                    msg = "Thank-you for choosing our venue for Reception Ceremony!";
                    break;
                case "Co-operate Event": // Co-operate Event
                    msg = "Thank-you for choosing our venue for Co-operate Event!";
                    break;
                case "Birthday Party": // Birthday Party
                    msg = "Thank-you for choosing our venue for Birthday Party!";
                    break;
                case "Anniversary Party": // Anniversary Party
                    msg = "Thank-you for choosing our venue for Anniversary Party!";
                    break;
                case "Baby Shower": // Baby Shower
                    msg = "Thank-you for choosing our venue for Baby Shower!";
                    break;
                case "Naming Ceremony": // Naming Ceremony
                    msg = "Thank-you for choosing our venue for Naming Ceremony!";
                    break;

            }



            document.getElementById("msg").textContent = msg;


            // Enable pay button if price is valid
            submit_button.disabled = msg ? false : true;

        });




    </script>

</body>

</html>