<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banquet hall - ABOUT US</title>
    <?php require('include/links.php');?>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <?php require ('include/header.php'); ?>
    <style>
        .box {
            border-top-color: var(--teal) !important;
        }
    </style>

</head>

<body class="bg-light">

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center">ABOUT US</h2>
        <div class="h-line bg-dark "></div>
        <p class="text-center mt-3">
            Our management team comprises seasoned professionals with a passion for event excellence. With a shared
            commitment to delivering exceptional experiences, each member of our management team is dedicated to
            ensuring every aspect of your event exceeds expectations.
        </p>
    </div>

    <div class="container">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-6 col-md-5 mb-4 order-lg-1 order-md-1 order-2">
                <h3 class="mb-3">Raghav Shastri</h3>
                <h5>(Founder of Grand Banquet hall)</h5>
                <p>
                    Raghav Shastri, the founder of our esteemed banquet hall, has dedicated his career to creating
                    unforgettable event experiences happening in the hall. With a profound passion for hospitality
                    and a wealth of industry expertise, Raghav has curated an exceptional venue where various events
                    come to life. His visionary leadership and commitment to excellence have positioned our banquet
                    hall as a premier destination for various kinds of celebrations. His visionary leadership ensures
                    flawless execution, leaving lasting impressions on guests.
                </p>
            </div>
            <div class="col-lg-5 col-md-5 mb-4 order-lg-2 order-md-2 order-1">
                <img src="images/founder.jpg" class="w-100">
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/details/info1.jpg" width="80px" style="height: 70px;">
                    <h4 class="mt-3">500+ customer</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/details/info2.jpg" width="80px" style="height: 70px;">
                    <h4 class="mt-3">200+ review</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/details/info3.jpg" width="80px" style="height: 70px;">
                    <h4 class="mt-3">100+ staff</h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/details/info4.jpg" width="80px" style="height: 70px;">
                    <h4 class="mt-3">2 floor</h4>
                </div>
            </div>
        </div>
    </div>

    <h3 class="my-5 fw-bold h-font text-center">MANAGEMENT TEAM</h3>

    <div class="container px-4">
        <div class="swiper mySwiper">
            <div class="swiper-wrapper mb-5">
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person1.jpg" class="w-100" style="height: 500px">
                    <h5 class="mt-2">Kunal Shetty</h5>  
                </div>                 
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person2.jpg" class="w-100" style="height: 500px;" >
                    <h5 class="mt-2">Kiara Khanna</h5>  
                </div>    
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person3.jpg" class="w-100" style="height: 500px;">
                    <h5 class="mt-2">Abhishek Rathod</h5>  
                </div>    
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person4.jpg" class="w-100" style="height: 500px;">
                    <h5 class="mt-2">Diana Fernandez</h5>  
                </div>    
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person5.jpg" class="w-100" style="height: 500px;">
                    <h5 class="mt-2">Rohit Shah</h5>  
                </div>
                <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                    <img src="images/about/person6.jpg" class="w-100" style="height: 500px;">
                    <h5 class="mt-2">Sonia Singh</h5>  
                </div>      
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div> 

    
    <?php require ('include/footer.php'); ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>

    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            spaceBetween: 40,
            pagination: {
                el: ".swiper-pagination",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 3,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });
    </script>
</body>

</html>