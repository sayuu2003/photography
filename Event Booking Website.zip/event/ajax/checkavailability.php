<?php

require ('../admin/include/db_config.php');
require ('../admin/include/essentials.php');

if (isset($_POST['check'])) {
    $data = filteration($_POST);


    $u_exist = select("SELECT * FROM `booking_detail` WHERE `date` = ? AND `timeslot` = ? LIMIT 1", [$data['date'], $data['timeslot']], "ss");

    if (mysqli_num_rows($u_exist) != 0) {
        echo 'checking';
    }else {
        echo 1;
    }


}
?>