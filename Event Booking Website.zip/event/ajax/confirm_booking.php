<?php

require ('../admin/include/db_config.php');
require ('../admin/include/essentials.php');


if(isset($_POST['booking']))
{
$data = filteration($_POST);


$u_exist = select("SELECT * FROM `booking_detail` WHERE `date` = ? AND `timeslot` = ? LIMIT 1", [$data['date'], $data['timeslot']], "ss");

if (mysqli_num_rows($u_exist) != 0) {
    // If booking exists for the selected date and time slot, return an error message
    echo 'booking_already';
    exit;
}



// If booking does not exist, proceed with the insertion
$query = "INSERT INTO `booking_detail` (`name`, `phonenum`, `address`, `date`, `timeslot`, `event`) VALUES (?, ?, ?, ?, ?, ?)";
$values = [$data['name'], $data['phonenum'], $data['address'], $data['date'], $data['timeslot'], $data['event']];

if (insert($query, $values, 'ssssss')) {
    echo 1; // Insertion successful
}
else {
    echo 'ins_failed'; // Insertion failed
}

}

?>