<?php

require ('../admin/include/db_config.php');
require ('../admin/include/essentials.php');

if(isset($_POST['info_form']))
{
    $frm_data = filteration($_POST);
    session_start();

    $query = "UPDATE `user_cred` SET `name`=?, `lastname`=?, `email`=?, `phonenum`=?, `address`=?, `pincode`=?, `dob`=? WHERE id=?";
    $values = [$frm_data['name'],$frm_data['lastname'],$frm_data['email'],$frm_data['phonenum'],$frm_data['address'],$frm_data['pincode'],$frm_data['dob'],$_SESSION['uId']];

    if(update($query,$values,'ssssssss')){
        $_SESSION['uName']=$frm_data['name'];
        $_SESSION['uLastname']=$frm_data['lastname'];
        echo 1;
    }
    else{
        echo 0;
    }
}


if(isset($_POST['pass_form']))
{
    $frm_data = filteration($_POST);
    session_start();

    if($frm_data['new_pass']!=$frm_data['confirm_pass']){
       echo 'mismatch';
       exit;
    }

    $enc_pass = password_hash($frm_data['new_pass'],PASSWORD_BCRYPT);
    
    $query ="UPDATE `user_cred` SET `pass`=? WHERE `id`=? LIMIT 1"; 

    $values = [$enc_pass,$_SESSION['uId']];

    if(update($query,$values,'ss')){
        echo 1;
    }
    else{
        echo 0;
    }
}



?>