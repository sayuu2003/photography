<?php
require ('include/essentials.php');
require ('include/db_config.php');
adminLogin();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>manage</title>
    <?php require ('include/link.php'); ?>
</head>

<body class="bg-light">
    <?php require ('include/header.php'); ?>

    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
                <h3 class="mb-4">MANAGE</h3>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <div class="text-end mb-4">
                            <button type="button" class="btn btn-dark shadow-none btn-sm" data-bs-toggle="modal"
                                data-bs-target="#add-event">
                                <i class="bi bi-plus-square"></i>Add
                            </button>
                        </div>

                        <div class="table-responsive-lg" style="height: 450px; overflow-y: scroll; ">
                            <table class="table table-hover border text-center">
                                <thead>
                                    <tr class="bg-dark text-light">
                                        <th scope="col">id</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">description</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="event-detail">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <!-- Add event modal -->

    <div class="modal fade" id="add-event" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="add_event_form">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Event</h5>
                    </div>
                    <div class="modal-body">
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Image</label>
                            <input type="file" name="image" class="form-control shadow-none">
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Name</label>
                            <input type="text" name="name" class="form-control shadow-none" required>
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Price</label>
                            <input type="number" name="price" class="form-control shadow-none" required>
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" rows="4" class="form-control shadow-none" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn text-secondary shadow-none"
                            data-bs-dismiss="modal">CANCEL</button>
                        <button type="submit" class="btn custom-bg text-white shadow-none">SUBMIT</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit event modal -->

    <div class="modal fade" id="edit-event" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="edit_event_form">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Event</h5>
                    </div>
                    <div class="modal-body">
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Image</label>
                            <input type="file" name="image" accept=".jpg, .png, .webp, .jpeg" class="form-control shadow-none">
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Name</label>
                            <input type="text" name="name" class="form-control shadow-none" required>
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Price</label>
                            <input type="number" name="price" class="form-control shadow-none" required>
                        </div>
                        <div class=" col-md-12 mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" rows="4" class="form-control shadow-none" required></textarea>
                        </div>
                        <input type="hidden" name="id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn text-secondary shadow-none"
                            data-bs-dismiss="modal">CANCEL</button>
                        <button type="submit" class="btn custom-bg text-white shadow-none">SUBMIT</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php require ('include/scripts.php'); ?>

    <script>
        let add_event_form = document.getElementById('add_event_form');
        add_event_form.addEventListener('submit', function (e) {
            e.preventDefault();
            add_event();
        });

        function add_event() {
            let data = new FormData();
            data.append('add_event', '');
            data.append('image',add_event_form.elements['image'].files[0]);
            data.append('name', add_event_form.elements['name'].value);
            data.append('price', add_event_form.elements['price'].value);
            data.append('description', add_event_form.elements['description'].value);


            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/manage.php", true);

            xhr.onload = function () {
                var myModal = document.getElementById('add-event');
                var modal = bootstrap.Modal.getInstance(myModal);
                modal.hide();

                if (this.responseText == 1) {
                    alert('success', 'Added Successfully!');
                    add_event_form.reset();

                }
                else {
                    alert('error', 'Server Down!');
                }
            }
            xhr.send(data);
        }

        function get_all_event() {

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/manage.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.onload = function () {
                document.getElementById('event-detail').innerHTML = this.responseText;
            }
            xhr.send('get_all_event');
        }

        window.onload = function () {
            get_all_event();
        }

        let edit_event_form = document.getElementById('edit_event_form');
        function edit_detail(id) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/manage.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.onload = function () {

            }
        }
    </script>

</body>

</html>