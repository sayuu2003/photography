<?php

require ('../include/db_config.php');
require ('../include/essentials.php');
adminLogin();

if (isset($_POST['get_data'])) {
    $res = selectAll('booking_detail');
    $i = 1;

    $data = "";

    while ($row = mysqli_fetch_assoc($res)) {
        $del_btn = "<button type= 'button' onclick='remove($row[sr_no])' class='btn btn-danger shadow-none'>
            <i class='bi bi-trash'></i>
            </button>";  
    
        $data .= "
               <tr>
                    <td> $i</td>
                    <td> $row[name]</td>
                    <td> $row[phonenum]</td>
                    <td> $row[address]</td>
                    <td> $row[date]</td>
                    <td> $row[timeslot]</td>
                    <td> $row[event]</td>
                    <td>$del_btn</td> 
                </tr> 
            ";
        $i++;
    }
    echo $data;
}




if (isset($_POST['remove'])) {
    $frm_data = filteration($_POST);
    $res = delete("DELETE FROM `booking_detail` WHERE `sr_no`=?", [$frm_data['book_id']], 'i');
    echo $res;

}




if (isset($_POST['search_data'])) {
    $frm_data = filteration($_POST);

    $query = "SELECT * FROM `booking_detail` WHERE `name` LIKE ?";

    $res = select($query, ["%$frm_data[name]%"], 's');
    $i = 1;

    $data = "";


    while ($row = mysqli_fetch_assoc($res)) {
        $del_btn = "<button type= 'button' onclick='remove($row[sr_no])' class='btn btn-danger shadow-none'>
            <i class='bi bi-trash'></i>
            </button>";
        

    
        $data .= "
               <tr>
                    <td>$i</td>
                    <td>$row[name]</td>
                    <td>$row[phonenum]</td>
                    <td>$row[address]</td>
                    <td>$row[date]</td>
                    <td>$row[timeslot]</td>
                    <td>$row[event]</td>
                    <td>$status</td>
                    <td>$del_btn</td> 

                </tr> 
            ";
        $i++;
    }
    echo $data;
}






?>