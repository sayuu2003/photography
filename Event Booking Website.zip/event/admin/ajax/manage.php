<?php
    require('../include/db_config.php');
    require('../include/essentials.php');
    adminLogin();


    if(isset($_POST['add_event']))
    {
        $frm_data=filteration($_POST);
        $flag=0;

        $q1 = "INSERT INTO `manage`(`name`, `price`, `description`) VALUES (?,?,?)";
        $values = [$frm_data['name'],$frm_data['price'],$frm_data['description']];

        if(insert($q1,$values,'sis')){
           $flag=1;
        }   

        $id = mysqli_insert_id($con);

        if($flag){
            echo 1;
        }
        else{
            echo 0;
        }
        
    }

    if(isset($_POST['get_all_event']))
    {
       $res = selectAll('manage');
       $i=1;

       $data= "";

       while($row = mysqli_fetch_assoc($res))
       {
        $data.="
        <tr class='align-middle'>
            <td>$i</td>
            <td>$row[name]</td>
            <td>₹$row[price]</td>
            <td>$row[description]</td>
            <td>image</td>
            <td>
                <button type='button' onclick='edit_detail' class='btn btn-primary shadow-none btn-sm' data-bs-toggle='modal' data-bs-toggle='modal' data-bs-target='#edit-event'>
                    <i class='bi bi-pencil-square'></i>
                </button>
            </td>   
        </tr>
        ";
        $i++;

       }

       echo $data;
        
    }


?>