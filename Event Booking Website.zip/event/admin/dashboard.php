<?php
require ('include/essentials.php');
require('include/db_config.php');
adminLogin();
session_regenerate_id(true);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Dashboard</title>
    <?php require ('include/link.php'); ?>
</head>


<body class="bg-light">


<?php require ('include/header.php'); 

    $user_details = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(id) AS `count` FROM `user_cred` "));
    $user_queries = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(sr_no) AS `count` FROM `user_queries` "));
    $booking_detail = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(sr_no) AS `count` FROM `booking_detail` "));


?>
    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4  overflow-hidden">
                <div class="d-flex align-items-center justify-content-between mb-4">                   
                    <h3>DASHBOARD</h3>
                </div>    

                <div class="row mb-6">
                    <div class="col-md-4 mb-4">
                        <a href="user.php" class="text-decoration-none">
                            <div class="card text-center text-success p-3 custom-card" style="height: 300px;">
                                <h6>User Registration</h6>
                                <h1 class="mt-2 mb-0"><?php echo $user_details['count']?></h1>
                            </div>
                        </a>
                    </div>  
                    
                    <div class="col-md-4 mb-4">
                        <a href="user.php" class="text-decoration-none">
                            <div class="card text-center text-warning p-3 custom-card" style="height: 300px;">
                                <h6>User Query</h6>
                                <h1 class="mt-2 mb-0"><?php echo $user_queries['count']?></h1>
                            </div>
                        </a>
                    </div>  

                    <div class="col-md-4 mb-4">
                        <a href="user.php" class="text-decoration-none">
                            <div class="card text-center text-primary p-3 custom-card" style="height: 300px;">
                                <h6>User Bookings</h6>
                                <h1 class="mt-2 mb-0"><?php echo $booking_detail['count']?></h1>
                            </div>
                        </a>
                    </div>  
                </div>
            </div>
        </div>
    </div>   




    <?php require ('include/scripts.php'); ?>

</body>

</html>