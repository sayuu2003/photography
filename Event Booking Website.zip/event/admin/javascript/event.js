
function get_data()
{
    let xhr = new XMLHttpRequest();
    xhr.open("POST","ajax/event.php",true);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.onload = function(){
        document.getElementById('event-book').innerHTML = this.responseText;  
    }
    xhr.send('get_data');

}



function remove(book_id)
{
   if(confirm("Are you sure, you want to remove this user?")) 
   {
    let data = new FormData();
    data.append('book_id',book_id);
    data.append('remove','');

    let xhr = new XMLHttpRequest();
    xhr.open("POST","ajax/event.php",true);

    xhr.onload = function()
    {
        if(this.responseText == 1){
            alert('success','User Removed!')
            get_data();
        }
        else{
            alert('error','User Removal Failed!')
        }
    }
    xhr.send(data);
   }
}

function search_data(username)
{
    let xhr = new XMLHttpRequest();
    xhr.open("POST","ajax/event.php",true);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

    xhr.onload = function(){
        document.getElementById('event-book').innerHTML = this.responseText;  
    }
    xhr.send('search_data&name='+ username);
}



window.onload = function(){
    get_data();
}




