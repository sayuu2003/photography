<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require ('include/links.php'); ?>
    <title>CONFIRM BOOKING</title>

</head>
<?php require ('include/header.php'); ?>


<body class="bg-light">

    <?php
    $book_btn = " ";

    if (!$settings_r['shutdown']) {
        $login = 0;
        if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
            $login = 1;
        }
        $book_btn = "<button onclick='checkLoginToBook($login)' class='btn btn-sm w-100 text-white custom-bg shadow none'>Book now</a>";
    }

    ?>




    <div class="container">
        <div class="row">
            <div class="col-12 my-5 mb-4 px-4">
                <h2 class="fw-bold">RECEPTION CEREMONY</h2>
                <div style="font-size: 14px;">
                    <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                    <span class="text-secondary"> > </span>
                    <a href="events.php" class="text-secondary text-decoration-none">EVENTS</a>
                    <span class="text-secondary"> > </span>
                    <a href="#" class="text-secondary text-decoration-none">RECEPTION</a>
                </div>
            </div>

            <div class="col-lg-7 col-md-12 px-4">
                <div class="card p-3 shadow-sm rounded mb-3">
                    <img src="images/occassion/Reception.jpg" style="height: 500px">
                </div>
            </div>

            <div class="col-lg-5 col-md-12 px-4">
                <div class="card mb-4 p-3 border-0 shadow-sm rounded-3 align">
                    <div class="card-body">
                        <h2 class="mb-5">Details</h2>
                        <h4 class="mt-4">Reception Ceremony</h4>
                        <h6 >₹55000</h6>
                        <div class="rating">
                            <i class="bi-star-fill text-warning"></i>
                            <i class="bi-star-fill text-warning"></i>
                            <i class="bi-star-fill text-warning"></i>
                            <i class="bi-star-fill text-warning"></i>
                            <i class="bi-star-half text-warning"></i>
                        </div>
                        <h6 class="fw-bold mt-5">Capacity of Guest:</h6>
                            <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                100-1200
                            </span>
                        <h6 class="fw-bold mt-4">Area:</h6>
                        <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                            2100 (built up) sq.ft
                        </span>
                        <h6 class="fw-bold mt-4">Feature:</h6>
                        <span class="badge square-pill bg-light text-dark text-wrap lh-base mb-2">
                           A/C hall
                        </span>
                        
                    </div>
                    <?php echo $book_btn ?>
                </div>
            </div>

            <div class="col-12 mt-4 px-4">
                <div class="card p-1 shadow-sm rounded mb-3">
                    <div class="card-body">
                    <h4 class="mb-3">Description</h4>
                        <p>
                            This "Floral Wreath" hanging overhead is the ideal decoration for Indo-Western Reception. This floral arrangement adds elegance and sophistication to your reception ceremony. To complete the look of this beautiful floral arrangement, we recommend adding some vintage chandeliers as well.
                        </p>
                    </div>
                </div>

            </div>
        </div>







        <?php require ('include/footer.php'); ?>
</body>

</html>