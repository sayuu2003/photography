<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banquet hall</title>
    <?php require ('include/links.php'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
</head>

<body class="bg-light">

    <?php require ('include/header.php'); ?>

    <!--carousel-->

    <div class="container-fluid px-lg-4 mt-4">
        <div class="swiper swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="images/carousel/1.jpg" class="w-100 d-block" style="height:565px" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/2.jpg" class="w-100 d-block" style="height: 565px;" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/3.jpg" class="w-100 d-block" style="height: 565px;" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/4.jpg" class="w-100 d-block" style="height: 565px;" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/5.jpg" class="w-100 d-block" style="height: 565px;" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/6.jpg" class="w-100 d-block" style="height: 565px;" />
                </div>
            </div>
        </div>
    </div>


    <!--check availability form-->

    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-12 bg-white shadow p-3 rounded">
                <h5 class="mb-4">Check Booking Availability</h5>
                <form action="#" id="check-form">
                    <div class="row align-items-end">
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Date</label>
                            <input type="date" name="date" class="form-control shadow-none" required>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Time Slot</label>
                            <select name="timeslot" class="form-select shadow-none">
                                <option value="1">8:00am-3:00pm</option>
                                <option value="2">4:00pm-10:00am</option>
                                <option value="3">8:00am-10:00pm</option>
                            </select>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500;">Event</label>
                            <select class="form-select shadow-none">
                                <option value="1">Wedding Ceremony</option>
                                <option value="2">Engagement Ceremony</option>
                                <option value="3">Reception Ceremony</option>
                                <option value="4">Co-operate Event</option>
                                <option value="5">Birthday party</option>
                                <option value="6">Anniversary Party</option>
                                <option value="7">Baby Shower</option>
                                <option value="8">Naming Ceremony</option>
                            </select>
                        </div>
                        <div class="col-lg-3 mb-lg-3 d-flex justify-content-center ">
                            <button type="submit" class="btn text-white shadow-none custom-bg">Submit</button>
                        </div>
                    </div>
                </form>
                <div>
                </div>
            </div>


            <!--EVENT details-->

            <?php
            $book_btn = " ";

            if (!$settings_r['shutdown']) {
                $login = 0;
                if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
                    $login = 1;
                }
                $book_btn = "<button onclick='checkLoginToBook($login)' class='btn btn-sm text-white custom-bg shadow none'>Book now</button>";
            }


            ?>

            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">EVENT DETAILS</h2>

            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 my-3">
                        <div class="card border-0" style="max-width:350px; margin:auto;">
                            <a href="wedding.php" style="text-decoration:none; color: inherit;">
                                <img src="images/occassion/Wedding.jpg" class="card-img-top" style="height:350px;">
                            </a>
                            <div class="card-body">
                                <a href="wedding.php" style="display: contents; text-decoration:none; color: inherit;">
                                    <h5>Wedding Ceremony</h5>
                                    <h6 class="mb-4">₹80000</h6>
                                    <div class="details mb-4">
                                        <h6 class="mb-1">Description:</h6>
                                        <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                            The "Dazzling Floral Accents Decoration" has roses and orchids arranged beautifully. Colorful drapes add style to the wedding stage. Each flowerlooks stunning and makes the place more special. It catches everyone's attention with its beauty and grandeur. The whole setup is elegant and impressive.
                                        </span>
                                    </div>
                                </a>
                                <div class="d-flex justify-content-evenly mb-2 a-none">
                                    <?php echo $book_btn ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 my-3">
                        <div class="card border-0" style="max-width:350px; margin:auto;">
                            <a href="Engagement.php" style="text-decoration:none; color: inherit;">
                                <img src="images/occassion/Engagement.jpg" class="card-img-top" style="height:350px;">
                            </a>
                            <div class="card-body">
                                <a href="Engagement.php"
                                    style="display: contents; text-decoration:none; color: inherit;">
                                    <h5>Engagement Ceremony</h5>
                                    <h6 class="mb-4">₹62000</h6>
                                    <div class="details mb-4">
                                        <h6 class="mb-1">Description:</h6>
                                        <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                            The "Radiant Roses Stage Decoration" for an engagement ceremony showcases vibrant clusters of roses cascading elegantly from every corner of the stage. Lush greenery complements the roses, while soft lighting accentuates the floral arrangements, creating an enchanting ambiance for the celebration.
                                        </span>
                                    </div>
                                </a>
                                <div class="d-flex justify-content-evenly mb-2">
                                    <?php echo $book_btn ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 my-3">
                        <div class="card border-0" style="max-width:350px; margin:auto;">
                            <a href="Reception.php" style="text-decoration:none; color: inherit;">
                                <img src="images/occassion/Reception.jpg" class="card-img-top" style="height:350px;">
                            </a>
                            <div class="card-body">
                                <a href="Reception.php"
                                    style="display: contents; text-decoration:none; color: inherit;">
                                    <h5>Reception Ceremony</h5>
                                    <h6 class="mb-4">₹55000</h6>
                                    <div class="details mb-4">
                                        <h6 class="mb-1">Description:</h6>
                                        <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                            This "Floral Wreath" hanging overhead is the ideal decoration for Indo-Western Reception. This floral arrangement adds elegance and sophistication to your reception ceremony. To complete the look of this beautiful floral arrangement, we recommend adding some vintage chandeliers as well.
                                        </span>
                                    </div>
                                </a>
                                <div class="d-flex justify-content-evenly mb-2">
                                    <?php echo $book_btn ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 text-center mt-5">
                        <a href="events.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More
                            Events >>></a>
                    </div>
                </div>
            </div>

            <!-- video-->
            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">WATCH VIDEO!</h2>

            <div class="container">
                <div class="text-center">
                    <iframe width="100%" height="550" style="object-fit:fill;"
                        src="https://www.youtube.com/embed/AZ3MTwZ-Fds?rel=0" title="YouTube video player"
                        frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
            </div>

            <!--Our services-->

            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">SERVICES</h2>
            <h5 class=" text-center text-wrap lh-base h-font">
                Contact to Our caters and photographer for their services.
            </h5>

            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 my-3">
                        <div class="card border-0" style="max-width:480px; margin:auto;">
                            <a href="https://www.cateringcorner.in/" target="_blank"
                                style="text-decoration:none; color: inherit;">
                                <img src="images/services/catering.jpg" class="card-img-top" style="height:480px;">
                                <div class="card-body bg-dark text-white text-center">
                                    <h5>Catering Services</h5>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 my-3">
                        <div class="card border-0" style="max-width:480px; margin:auto;">
                            <a href="https://www.phototantra.com/" target="_blank"
                                style="text-decoration:none; color: inherit;">
                                <img src="images/services/photographer.jpg" class="card-img-top" style="height: 480px;">
                                <div class="card-body bg-dark text-white text-center">
                                    <h5>Photography Services</h5>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!--Our facilities-->

            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR FACILITIES</h2>
            <div class="container">
                <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="images/facilities/air_condition.png" width="80px">
                        <h5>Air Condition</h5>
                    </div>
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="images/facilities/parking.png" width="80px">
                        <h5>Parking Area</h5>
                    </div>
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="images/facilities/lift.png" width="80px">
                        <h5>Elevator</h5>
                    </div>
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="images/facilities/selfie.png" width="80px">
                        <h5 class="mt-1">Selfie Point</h5>
                    </div>
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="images/facilities/sound_system.png" width="80px">
                        <h5 class="mt-2">Music System</h5>
                    </div>
                    <div class="col-lg-12 text-center mt-5">
                        <a href="facilities.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More
                            Facilities >>></a>
                    </div>
                </div>
            </div>

            <!--feedback-->
            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">FEEDBACK</h2>
            <div class="container mt-5">
                <div class="swiper swiper-testimonals">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic1.jpg" width="30px">
                                <h6 class="m-0 ms-2">Khushi Singh</h6>
                            </div>
                            <p>
                                Arrangements are all set and perfect as needed. My suggestion for you all is that just go for it without thinking , best hall for any kind of event.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic2.jpg" width="30px">
                                <h6 class="m-0 ms-2">Anjali Patil</h6>
                            </div>
                            <p>
                                As specially I would like to appreciate the management & staff as they have made sure everything fall into perfect place as required by us.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic3.jpg" width="30px">
                                <h6 class="m-0 ms-2">Rohit Kapoor</h6>
                            </div>
                            <p>
                                Classy halls with bright and positive atmosphere in entire Banquet hall. Supportive staff and mesmerising decoration.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-half text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic4.jpg" width="30px">
                                <h6 class="m-0 ms-2">Annie Dsouza</h6>
                            </div>
                            <p>
                                The facilities were top-notch, and the event coordination was seamless.Will definitely consider using this venue again for future events.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic5.jpg" width="30px">
                                <h6 class="m-0 ms-2">George Roy</h6>
                            </div>
                            <p>
                                The venue was spacious and well-maintained, and the staff were professional and accommodating. Overall, a great experience.

                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic6.jpg" width="30px">
                                <h6 class="m-0 ms-2">Anushka Verma</h6>
                            </div>
                            <p>
                                The venue exceeded my expectations, and my guests were impressed by the atmosphere. Highly recommended for any kind of events.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic7.jpg" width="30px">
                                <h6 class="m-0 ms-2">Ronak Shah</h6>
                            </div>
                            <p>
                                Throughout my experience, the venue was equipped with everything we needed, including audiovisual equipment and rest of the things.
                            </p> 
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                        <div class="swiper-slide bg-white p-4">
                            <div class="profile d-flex align-items-center mb-3">
                                <img src="images/customer/profile_pic8.jpg" width="30px">
                                <h6 class="m-0 ms-2">Shreyash Joshi</h6>
                            </div>
                            <p>
                                The venue was conveniently located, and the layout was conducive to networking and discussions. Overall, a positive experience.
                            </p>
                            <div class="rating">
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                                <i class="bi-star-fill text-warning"></i>
                            </div>
                        </div>

                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>



            <!--Reach us-->


            <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">REACH US</h2>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
                        <iframe class="w-100 rounded" height="320px" src="<?php echo $contact_r['iframe'] ?>"
                            loading="lazy"></iframe>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="bg-white p-4 rounded mb-4">
                            <h5>Call us</h5>
                            <a href="tel: +<?php echo $contact_r['pn1'] ?>"
                                class="d-inline-block mb-2 text-decoration-none text-dark">
                                <i class="bi bi-telephone-fill"></i> +<?php echo $contact_r['pn1'] ?>
                            </a>
                            <br>

                            <a href="tel: +<?php echo $contact_r['pn2'] ?>"
                                class="d-inline-block text-decoration-none text-dark">
                                <i class="bi bi-telephone-fill"></i> +<?php echo $contact_r['pn2'] ?>
                            </a>

                        </div>
                        <div class="bg-white p-4 rounded mb-4">
                            <h5>Email us</h5>
                            <a href="mailto: <?php echo $contact_r['email'] ?>"
                                class="d-inline-block mb-2 text-decoration-none text-dark">
                                <i class="bi bi-envelope-fill"></i> <?php echo $contact_r['email'] ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <?php require ('include/footer.php'); ?>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
                crossorigin="anonymous"></script>

            <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
            <script>

                let check_form = document.getElementById('check-form');
                check_form.addEventListener('submit', (e) => {
                    e.preventDefault();

                    let today = new Date();
                    today.setHours(0, 0, 0, 0); // Set hours to 0 for accurate comparison

                    // Get the selected date from the form
                    let selectedDate = new Date(check_form.elements['date'].value);

                    // Check if the selected date is less than today's date
                    if (selectedDate <= today) {
                        alert('error', "Invalid Date");
                        return; // Prevent form submission if the date is invalid
                    }

                    let data = new FormData();

                    data.append('date', check_form.elements['date'].value);


                    // Get the selected time slot value and store it in the FormData
                    let selectedTimeSlotValue = check_form.elements['timeslot'].value;
                    data.append('timeslot', selectedTimeSlotValue);
                    data.append('check', '');

                    let xhr = new XMLHttpRequest();
                    xhr.open('POST', 'ajax/checkavailability.php', true);

                    xhr.onload = function () {
                        if (this.responseText == 'checking') {
                            alert('error', "Booking is not available!");
                        } else {
                            alert('success', "Booking is available!");
                        }
                    }
                    xhr.send(data); // Moved outside the onload function
                });


                var swiper = new Swiper(".swiper-container", {
                    spaceBetween: 30,
                    effect: "fade",
                    loop: true,
                    autoplay: {
                        delay: 3500,
                        disableOnInteraction: false,
                    }
                });

                document.addEventListener('keydown', function (event) {
                    if (event.key === "ArrowLeft") {
                        swiper.slidePrev();
                    } else if (event.key === "ArrowRight") {
                        swiper.slideNext();
                    }
                });


                var Swiper = new Swiper(".swiper-testimonals", {
                    effect: "coverflow",
                    grabCursor: true,
                    centeredSlides: true,
                    slidesPerView: "auto",
                    loop: true,
                    coverflowEffect: {
                        rotate: 50,
                        stretch: 0,
                        depth: 100,
                        modifier: 1,
                        slideShadows: false,
                    },
                    pagination: {
                        el: ".swiper-pagination",
                    },
                    breakpoints: {
                        320: {
                            slidesPerView: 1,
                        },
                        640: {
                            slidesPerView: 1,
                        },
                        768: {
                            slidesPerView: 2,
                        },
                        1024: {
                            slidesPerView: 3,
                        },
                    }
                });


            </script>
</body>

</html>