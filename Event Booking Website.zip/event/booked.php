<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require ('include/links.php'); ?>
    <title>BOOKING</title>
</head>

<body class="bg-light">

    <?php
    require ('include/header.php');
   
    $query= "SELECT * FROM booking_detail WHERE sr_no=?";
    $result=select($query,[$_SESSION['u_Id']],'i');

    $u_fetch = mysqli_fetch_assoc($result);

    
 
    ?>

    <div class="container">
        <div class="row">
            <div class="col-12 my-5 px-4">
                <h2 class="fw-bold">BOOKING STATUS</h2>
                <div style="font-size: 14px;">
                    <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                    <span class="text-secondary"> > </span>
                    <a href="#" class="text-secondary text-decoration-none">BOOKING</a>
                </div>
            </div>

            <div class="col-lg-5 col-md-12 px-4">
                <div class="card mb-4 p-3 border-0 shadow-sm rounded-3 align">
                    <div class="card-body">
                        <h2 class="mb-3 fw-bold">Booking info</h2>
                        <div class="row">
                           <h5>Name:<?php echo $u_fetch['name'] ?> <?php echo $u_fetch['lastname'] ?></h5>
                           <h5>Name:<?php echo $u_fetch['event'] ?> </h5>                                   
                                   
                        </div>
                    </div>    
                </div>
            </div>

            
            


        </div>
    </div>    

    <?php require('include/footer.php'); ?>

    </body>
</html>    
