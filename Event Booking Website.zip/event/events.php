<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banquet hall - EVENTS</title>
    <?php require ('include/links.php'); ?>

</head>
<?php require ('include/header.php'); ?>


<body class="bg-light">
    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center">EVENTS</h2>
        <div class="h-line bg-dark "></div>
        <p class="text-center mt-3">
            Step into the elegance of Grand Banquet! Discover the perfect venue for your special event, whether it's a
            wedding celebration or a professional gathering.<br> Secure your reservation today to create lasting
            memories that you'll cherish forever!
        </p>
    </div>

    <?php
    $book_btn = " ";

    if (!$settings_r['shutdown']) {
        $login = 0;
        if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
            $login = 1;
        }
        $book_btn = "<button onclick='checkLoginToBook($login)' class='btn btn-sm w-100 text-white custom-bg shadow none'>Book now</a>";
    }

    ?>

            <div class="col-lg-12 col-md-12 px-4">
                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="wedding.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Wedding.jpg" class="img-fluid rounded" style="height:300px; width:100%">
                        </div>
                        </a>
                        <a href="wedding.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Wedding Ceremony</h5>
                            <div class="details mb-4">
                                <h6 class="mb-1">Description:</h6>
                                <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    The "Dazzling Floral Accents Decoration" has roses and orchids arranged beautifully. Colorful drapes add style to the wedding stage. Each flower looks stunning and makes the place more special. It catches everyone's attention with its beauty and grandeur. The whole setup is elegant and impressive.
                                </span>
                            </div>
                        </div>
                        </a>
                        </div>
                            <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹80000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>
            

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">  
                        <a href="Engagement.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Engagement.jpg" class="img-fluid rounded" style="height:300px;  width:100%;">
                        </div>
                        </a>
                        <a href="Engagement.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Engagement Ceremony</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                        The "Radiant Roses Stage Decoration" for an engagement ceremony showcases vibrant clusters of roses cascading elegantly from every corner of the stage. Lush greenery complements the roses, while soft lighting accentuates the floral arrangements, creating an enchanting ambiance for the celebration.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹62000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="Reception.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Reception.jpg" class="img-fluid rounded" style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="Reception.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Reception Ceremony</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    This "Floral Wreath" hanging overhead is the ideal decoration for Indo-Western Reception. This floral arrangement adds elegance and sophistication to your reception ceremony. To complete the look of this beautiful floral arrangement, we recommend adding some vintage chandeliers as well.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹55000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="coperate.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Co-operate.jpg" class="img-fluid rounded"  style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="coperate.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Co-Operate Event</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    Elevate your corporate event with our expert decoration services. From elegant curtains to tasteful lighting arrangements, we'll transform your venue into a captivating oasis, aligning perfectly with your corporate aesthetic. Let us create a memorable ambiance that sets the stage for success.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹50000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="birthday.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Birthday.jpg" class="img-fluid rounded"  style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="birthday.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Birthday Party</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                        Balloon decorations bring instant vibrancy and joy to any event. With their versatility and affordability, they can be arranged into bouquets, arches, or sculptures, adding a playful touch to the atmosphere and delighting guests with their cheerful ambiance.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹30000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="anniversary.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Anniversary.jpg" class="img-fluid rounded"  style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="anniversary.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Anniversary Party</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    Celebrate your milestone in style with our stunning anniversary decoration featuring a captivating circle adorned with vibrant balloons and centered around a magnificent LED light display of the number 25. This dazzling centerpiece is sure to command attention and create a magical ambiance.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹40000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="babyshower.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Baby_shower.jpg" class="img-fluid rounded" style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="babyshower.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Baby Shower</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    Elevate your baby shower with charming decorations featuring pink and white flowers alongside pink and blue balloons, and  a floral moon design, symbolizing the journey of parenthood.Let this blend of elegance and whimsy set the stage for cherished memories as you eagerly await your little one's arrival.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹32000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

                <div class="card mb-4 border-0 shadow">
                    <div class="row g-0 p-3 align-items-center">
                        <a href="naming.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5">
                            <img src="images/occassion/Naming.jpg" class="img-fluid rounded" style="height:300px; width:100%;">
                        </div>
                        </a>
                        <a href="naming.php" style="display: contents; text-decoration:none; color: inherit;">
                        <div class="col-md-5 px-lg-3 px-md-3 px-0">
                            <div class="card-body">
                                <h5 class="mb-4">Naming Ceremony</h5>
                                <div class="details mb-4">
                                    <h6 class="mb-1">Description:</h6>
                                    <span class="badge square-pill bg-light text-dark text-wrap lh-base">
                                    The cradle stands as the centerpiece of the naming ceremony, draped in soft pastel fabrics and adorned with clusters of fresh white flowers and pink roses.Floral garlands trail along its sides, creating an elegant touch. Surrounding the cradle are additional floral accents, setting a joyful and celebratory atmosphere.
                                    </span>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="col-md-2 text-align-center">
                            <h6 class="mb-2 text-center">₹35000</h6>
                            <?php echo $book_btn ?>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <?php require ('include/footer.php'); ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>

</body>

</html>